const data=[
["MEP","Ciao - Melenzane","Qatar Foundation – QF Education City","Completed","Complete turnkey fit-out including consultant arrangement, landlord coordination, demolition, civil works, marble finishes, kitchen equipment installation, HVAC and MEP systems including fire alarm, firefighting, CCTV and PA with QCDD inspection."],
["MEP","Sleep Gallery","Ahla Cloudnine Trading – Doha Mall","Completed","Complete turnkey fit-out including consultant arrangement, landlord coordination, demolition, civil works, marble finishes, kitchen equipment installation, HVAC and MEP systems including fire alarm, firefighting, CCTV and PA with QCDD inspection."],
["MEP","Bravo Trading","Doha Mall","Completed","Complete MEP installation including fire alarm, firefighting, CCTV, PA and HVAC system with QCDD inspection."],
["MEP","Ajantic","Doha Mall","Completed","Complete MEP installation including fire alarm, firefighting, CCTV, PA and HVAC system with QCDD inspection."],
["MEP","Mary Brown","Landmark Mall","Completed","Complete MEP installation including fire alarm, firefighting, CCTV, PA and HVAC system with QCDD inspection."],
["MEP","Al-Malaki Jewellery","Villagio Mall","Completed","Complete MEP installation including fire alarm, firefighting, CCTV, PA and HVAC system with QCDD inspection."],
["MEP","Suchi-Minto","Pearl Qatar – Porto Arabia","Completed","Complete MEP fit-out including fire alarm, firefighting, CCTV and PA system with QCDD inspection."],
["Civil","G+3 Building Renovation","Al Baker Group – Matar Qadeem","Completed","Renovation including floor tiles, drainage and electrical system replacement with painting and AC replacement."],
["Civil","Floor Interlock Replacement","Al Baker Group – Al Hilal","Completed","Replacement of floor interlock over an area of 530 sq.m."],
["Electrical","Electrical Panel Rectification","Sheikh Abdullah Al-Thani","Completed","Rectification of electrical panels with coordination of QatarEnergy and Kahramaa in Umm Bab and Al Mehanis."],
["Civil","Guard House Reconstruction","Sheikh Abdullah Al-Thani","Completed","Reconstruction of guard house at Umm Bab beach house and Al Mehanis farm house."],
["MEP","GIORDANA","DFC Mall","Ongoing","Complete MEP installation including fire alarm, firefighting, CCTV and PA system with QCDD inspection."],
["MEP","KARIZMA","City Center Mall","Ongoing","Complete MEP installation including fire alarm, firefighting, CCTV and PA system with QCDD inspection."],
["MEP","Orbit Consultancy Office","Salwa Road","Ongoing","Complete MEP installation including fire alarm, firefighting, CCTV and PA system with QCDD inspection."],
["MEP","Military Medical Hospital","Al Saniya","Completed","Additional power upgrade at HEER Coffee Shop."],
["Civil","Borewell Maintenance","QAF – Al Shainiya","Completed","Maintenance of borewells."],
["MEP","Joyful Office","Salwa Road","Ongoing","Complete MEP installation including fire alarm, firefighting, CCTV and PA system with QCDD inspection."],
["HVAC","AC Unit Maintenance","Labour Camp – Street 38","Completed","Maintenance of 1,350 AC units across three buildings, including cleaning, gas top-up and necessary spare-part replacement."]
];

const grid=document.getElementById("projectsGrid");
const projectImages={MEP:"assets/images/mep.jpg",Civil:"assets/images/civil.jpg",Electrical:"assets/images/mep.jpg",HVAC:"assets/images/fm.jpg"};
const modal=document.getElementById("modal");
function render(filter="all"){
  const list=filter==="all"?data:data.filter(x=>x[0]===filter);
  grid.innerHTML=list.map((p,i)=>`<article class="project reveal show" data-i="${data.indexOf(p)}" style="--project-image:url('${projectImages[p[0]]||projectImages.MEP}')"><div><div class="tag">${String(i+1).padStart(2,"0")} • ${p[0]}</div><h3>${p[1]}</h3><p>${p[2]}</p></div><div class="project-foot"><strong>${p[3]}</strong><span>VIEW ↗</span></div></article>`).join("");
  document.querySelectorAll(".project").forEach(el=>el.onclick=()=>{
    const p=data[+el.dataset.i];
    document.getElementById("mMeta").textContent=p[0]+" • "+p[2];
    document.getElementById("mTitle").textContent=p[1];
    document.getElementById("mDesc").textContent=p[4];
    document.getElementById("mStatus").textContent=p[3];
    modal.classList.add("open");document.body.style.overflow="hidden";
  });
}
render();
document.querySelectorAll(".project-toolbar button").forEach(b=>b.onclick=()=>{
  document.querySelectorAll(".project-toolbar button").forEach(x=>x.classList.remove("active"));
  b.classList.add("active");render(b.dataset.filter);
});
document.querySelector(".close").onclick=()=>{modal.classList.remove("open");document.body.style.overflow=""};
document.querySelector(".modal-bg").onclick=()=>{modal.classList.remove("open");document.body.style.overflow=""};
document.addEventListener("keydown",e=>{if(e.key==="Escape"){modal.classList.remove("open");document.body.style.overflow=""}});

const hamburger=document.querySelector(".hamburger"),nav=document.querySelector(".nav");
hamburger.onclick=()=>nav.classList.toggle("open");
document.querySelectorAll(".nav a").forEach(a=>a.onclick=()=>nav.classList.remove("open"));

const obs=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting)e.target.classList.add("show")}),{threshold:.12});
document.querySelectorAll(".reveal").forEach(x=>obs.observe(x));
document.getElementById("year").textContent=new Date().getFullYear();

document.getElementById("quoteForm").onsubmit=e=>{
 e.preventDefault();
 const f=new FormData(e.target);
 const subject=encodeURIComponent("DEFENDEX Website Enquiry - "+f.get("service"));
 const body=encodeURIComponent(`Name: ${f.get("name")}\nCompany: ${f.get("company")}\nEmail: ${f.get("email")}\nPhone: ${f.get("phone")}\nService: ${f.get("service")}\n\nProject details:\n${f.get("message")}`);
 location.href=`mailto:info@defendexco.com?subject=${subject}&body=${body}`;
 document.getElementById("formMessage").textContent="Your email client has been prepared with the enquiry.";
};
